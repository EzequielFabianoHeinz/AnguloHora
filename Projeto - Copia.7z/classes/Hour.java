package classes;

import java.util.GregorianCalendar;
import java.util.Calendar;

	public class Hour{
	//classe
	public  static long retornaAnguloRelogioHoraSistema(GregorianCalendar horario) {
	//c�lculo matematico conforme formula
		long h = 0;
		long min = horario.get(Calendar.MINUTE);
		
        long a = ((60 * h) - (11 * min)) / 2;        
        a = (a < 0)? a *= -1 : a;

        return a;
		}
	}
