import java.util.GregorianCalendar;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import classes.Hour;
import java.util.Calendar;
	
	public class somenteminuto extends JFrame {
					
			private JTextField campoHour;
			private JLabel label1, labelAngulo;
			private JButton btnTeste;

	
	public somenteminuto()	{
	
			setLayout(null);
		
			Font letra = new Font("Arial", Font.BOLD, 18);
			// cabe�alho
			labelAngulo = new JLabel("S� Minutos");
			labelAngulo.setBounds(10,05,450,50);
			labelAngulo.setFont(letra);
			add(labelAngulo);
			//cabe�alho 
			label1 = new JLabel("Informe os Minutos : ");
			label1.setBounds(10,45,200,50);
			label1.setFont(letra);
			add(label1);
			//campo onde a hora deve ser digitada
			campoHour = new JTextField();
			campoHour.setBounds(170,87,150,40);
			campoHour.setFont(letra);
			add(campoHour);
			//bot�o de execu��o
			btnTeste = new JButton("Executar");
			btnTeste.setBounds(170,150,150,40);
			btnTeste.setFont(new Font("Arial", Font.BOLD, 18));
			add(btnTeste);
			btnTeste.addActionListener(
				new ActionListener(){
					public void actionPerformed(ActionEvent e){
						Hour resultado = new Hour ();
						
						String hour = campoHour.getText();
						//fun��o de retornar o angulo e a hora informada						
						int h = 0;  
						int min = Integer.parseInt(hour);
						long angulo = resultado.retornaAnguloRelogioHoraSistema( new GregorianCalendar(0,0,0,h,min,0));
						labelAngulo.setText(h + ":" + min + "hs = " + angulo + "�");
					}
				}
			);	
		}
		
		public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == btnTeste)
		{
			String texto = campoHour.getText();
			setTitle(getTitle() + " " + texto);
		}
	}
		
			public static void main(String args[])
	{
		somenteminuto form1 = new somenteminuto();
		form1.setBounds(0,0,500,300);
		form1.setVisible(true);
		form1.setResizable(false);
		form1.setLocationRelativeTo(null);
		form1.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
}
